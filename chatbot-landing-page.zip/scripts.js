const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function sendMessage() {
    let message = userInput.value.trim();
    if (message === "") return;

    addMessage("You: " + message);
    userInput.value = "";

    setTimeout(() => {
        botResponse(message);
    }, 1000);
}

function addMessage(text) {
    let msg = document.createElement("p");
    msg.textContent = text;
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function botResponse(message) {
    let response = "";

    if (message.toLowerCase().includes("review")) {
        response = "Would you like to leave a review and receive a free Naan bread? (Yes/No)";
    } else if (message.toLowerCase() === "yes") {
        response = "Great! Where would you like to leave a review? (Google/Facebook)";
    } else if (message.toLowerCase() === "google") {
        response = "Please leave a review on Google: [Google Review Link].";
    } else if (message.toLowerCase() === "facebook") {
        response = "Please leave a review on Facebook: [Facebook Review Link].";
    } else if (message.toLowerCase() === "no") {
        response = "No problem! Thanks for visiting. Have a great day!";
    } else {
        response = "I'm not sure what you mean. Try saying 'review'!";
    }

    addMessage("Bot: " + response);
}
